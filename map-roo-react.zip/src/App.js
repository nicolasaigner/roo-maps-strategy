import React, { useState } from 'react';
import Map from './components/Map';
import Sidebar from './components/Sidebar';
import './App.css';

function App() {
    const [svgObject, setSvgObject] = useState(null);
    const [mapFile, setMapFile] = useState('/assets/svgs/2A.svg');

    const handleSvgLoad = (object) => {
        setSvgObject(object);
    };

    return (
        <div className="flex h-screen bg-gray-900 text-white">
            <Sidebar setMapFile={setMapFile} />
            <div className="flex-1 p-4 flex items-center justify-center">
                <Map onLoad={handleSvgLoad} mapFile={mapFile} />
            </div>
        </div>
    );
}

export default App;
