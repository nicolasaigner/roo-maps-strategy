import React, { useEffect, useRef, useState } from 'react';

const Map = ({ onLoad, mapFile }) => {
    const objectRef = useRef(null);
    const [zoom, setZoom] = useState(1);

    const handleLoad = () => {
        const svgObject = objectRef.current.contentDocument;
        if (svgObject) {
            onLoad(svgObject);
        } else {
            console.error('SVG content document is not accessible.');
        }
    };

    const handleZoom = (event) => {
        event.preventDefault();
        const newZoom = event.deltaY < 0 ? zoom * 1.1 : zoom * 0.9;
        setZoom(newZoom > 0.1 ? newZoom : zoom);
    };

    useEffect(() => {
        const objectElement = objectRef.current;
        objectElement.addEventListener('load', handleLoad);
        const container = objectElement.parentNode;

        container.addEventListener('wheel', handleZoom);

        return () => {
            objectElement.removeEventListener('load', handleLoad);
            container.removeEventListener('wheel', handleZoom);
        };
    }, [zoom, mapFile]);

    return (
        <div
            className="map-container relative flex-1 border-2 border-gray-700 rounded-lg overflow-hidden shadow-lg"
            style={{  width: '98vh', height: '98vh', padding: '10px', margin: '10px' }}
        >
            <object
                ref={objectRef}
                data={mapFile}
                type="image/svg+xml"
                className="svg-object w-full h-full"
                style={{ transform: `scale(${zoom})`, transformOrigin: 'center', height: '100%', width: '100%' }}
            />
        </div>
    );
};

export default Map;
